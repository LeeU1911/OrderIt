package com.bosch;

public class Constants {

	public static String authToken = "https://accounts.bosch.com/adfs/oauth2/token";
	public static String getInventory = "/api/inventory";
	public static String addInventory = "/api/inventory/%s";//%s - ProductID
	public static String deleteInventory = "/api/inventory";
	public static String productSearch = "/products/?keyWords=%s&page=%s&size=%s&sortField=%s&sortOrder=%s&lang=%s&dataset=%s"; //%s - Search data
	public static String productDetails = "/products/%s"; //%s - ProductID
	public static String productAttributes = "/products/productAttributes";
	public static String productByCategoryId = "/products/categories/%s?recursive=%s&pageSize=%s&pageNumber=%s&lang=%s&dataset=%s"; //%s - Category Id
}
