package com.bosch.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Class that extracts properties from the prop file.
 */
public class PropertyLoader {

  static Properties config;
  static Properties data;
  static Properties url;
	
  public static void loadConfigProperty(){
	  config = new Properties();
	  try {
		InputStream inputStream = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\config.properties");
		try {
			config.load(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  public static String getConfigProperty(String key){
	  return config.getProperty(key);
  }
  
  public static void loadTestDataProperty(){
	  String env = getConfigProperty("environment");
	  data = new Properties();
	  try{
		  InputStream inputStream = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\testdata_"+env+".properties");
		  try {
			data.load(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
  
  public static String getTestDataProperty(String key){
	  return data.getProperty(key);
  }
  
  public static void loadURLDataProperty(){
	  url = new Properties();
	  try{
		  InputStream inputStream = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\url.properties");
		  try {
			data.load(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }

  public static String getURLProperty(String key){
	  return data.getProperty(key);
  }
}