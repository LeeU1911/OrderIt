package com.bosch.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CreateExtentReport {

	public static String createReport(){
		String resultfolderPath = System.getProperty("user.dir")+ "\\Results";
		String summaryfileName = "Summary.html";
		String sResultsPath = resultfolderPath+getResultFolderName();
		String outputpath = "";
		File summaryFile = new File(sResultsPath + "\\" + summaryfileName);
		if (!summaryFile.exists()) {
			try {
				File dir = new File(sResultsPath);
				dir.mkdir();
				summaryFile.createNewFile();
				outputpath = sResultsPath + "\\" + summaryfileName;
			} catch (Exception e) {

				e.printStackTrace();
				throw new IllegalStateException("Error occured during Creation of result file. "+ e.getMessage());
			}
		}
		return outputpath;
	}
	
	public static String getResultFolderName() {
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		Date date = new Date();
		String dateTime = dateFormat.format(date);
		String reportFolderName= "\\Execution_"+dateTime+"_Report";
		return reportFolderName;
	}
	
}
