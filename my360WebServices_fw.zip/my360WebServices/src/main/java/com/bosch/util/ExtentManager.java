package com.bosch.util;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {

private static ExtentReports extent;
final static String filePath = CreateExtentReport.createReport();
static String env = PropertyLoader.getConfigProperty("environment");
    
    public synchronized static ExtentReports getReporter() {
    	if (extent == null) {
            extent = new ExtentReports(filePath, false, DisplayOrder.NEWEST_FIRST);
            
            extent
                .addSystemInfo("Environment", env);
        }
        
        return extent;
    }
    
    public static void endReport() {
    	extent.flush();
	}
}
