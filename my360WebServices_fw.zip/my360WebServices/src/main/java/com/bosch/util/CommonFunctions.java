package com.bosch.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;

public class CommonFunctions {

	public String getRequestJsonAsString(String fileName) {
		InputStream is = null;
		try {
			is = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\main\\resources\\Json\\" + fileName + ".json");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader buf = new BufferedReader(new InputStreamReader(is));
		String line = null;
		try {
			line = buf.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder sb = new StringBuilder();
		while (line != null) {
			sb.append(line).append("\n");
			try {
				line = buf.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String fileAsString = sb.toString();
		System.out.println("Contents : " + fileAsString);
		return fileAsString;
	}

	public void logReport(LogStatus status, String details) {
		ExtentTestManager.getTest().log(status, details);
		if (status.name().equalsIgnoreCase("FAIL")) {
			Assert.fail(details);
		}
	}

	public void logReport(LogStatus status, String details, Throwable e) {
		ExtentTestManager.getTest().log(status, details, e);
		if (status.name().equalsIgnoreCase("FAIL")) {
			Assert.fail(details);
		}
	}
	
	public void validateResponseCode(int expResponseCode, int actualRespCode){
		if(expResponseCode==actualRespCode){
			logReport(LogStatus.PASS, "Response code is displayed as expected: "+expResponseCode);
		}else{
			logReport(LogStatus.FAIL, "Response code is not displayed as expected: "+expResponseCode+" Actual code: "+actualRespCode);
		}
	}
	
	public void compareText(String expected,String actual){
		if(expected.equals(actual)){
			logReport(LogStatus.PASS, "Text is displayed as expected: "+expected);
		}else{
			logReport(LogStatus.FAIL, "Text is not displayed as expected: "+expected+" Actual code: "+actual);
		}
	}
	
	public List<String> getListOfElement(Response res,String expression){
		List<String> elementList = null; 
		try{
			ReadContext rx = JsonPath.parse(res.getBody().asString());
			elementList =rx.read(expression);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception while evaluating expression from Json response. Method: getListOfElement. Expression: "+expression);
		}
		return elementList;
	}
	
	public String getElement(Response res,String expression){
		String element = null; 
		try{
			ReadContext rx = JsonPath.parse(res.getBody().asString());
			element =rx.read(expression);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception while evaluating expression from Json response. Method: getListOfElement. Expression: "+expression);
		}
		return element;
	}
	
	public void validateResponseContent(Response res, boolean flag){
		String responseBody = res.body().asString();
		if(flag){
			if(!(responseBody.equals("[]")) || responseBody.isEmpty()){
				logReport(LogStatus.PASS, "Response body has content and it is not empty: "+responseBody);
			}else{
				logReport(LogStatus.FAIL, "Response body is empty which is not expected");
			}
		}else{
			if((responseBody.equals("[]")) || responseBody.isEmpty()){
				logReport(LogStatus.PASS, "Response body is empty which is expected: "+responseBody);
			}else{
				logReport(LogStatus.FAIL, "Response body is not empty which is not expected");
			}
		}
	}
}
