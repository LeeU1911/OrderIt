package com.bosch.util;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;

public class RestHelper extends CommonFunctions{
	
	static String token="";
	static String baseUrl="";
	
	protected Response callRestServiceGet(String url,String apiName){
		Response response = null;
		try{
			response =RestAssured.given().header(processHeader()).contentType(ContentType.JSON).get(url);
			logReport(LogStatus.PASS, "Executed Get method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Get method in API "+apiName, e);
		}
		return response;
	}
	
	protected Response callRestServiceGet(String url,Header header,ContentType contentType,String apiName){
		Response response = null;
		try{
			response =RestAssured.given().header(header).contentType(ContentType.JSON).get(url);
			logReport(LogStatus.PASS, "Executed Get method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Get method in API "+apiName, e);
		}
		return response;
	}
	
	protected Response callRestServicePost(String url,String body,String apiName){
		Response response = null;
		try{
			response= RestAssured.given().header(processHeader()).contentType(ContentType.JSON).body(body).when().post(url);
			logReport(LogStatus.PASS, "Executed Post method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Post method in API "+apiName, e);
		}
		return response;
	}
	
	protected Response callRestServicePost(String url,Header header,String body,ContentType contentType,String apiName){
		Response response = null;
		try{
			response= RestAssured.given().header(header).contentType(contentType).body(body).when().post(url);
			logReport(LogStatus.PASS, "Executed Post method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Post method in API "+apiName, e);
		}
		return response;
	}
	
	protected Response callRestServicePut(String url,String body,String apiName){
		Response response = null;
		try{
			response = RestAssured.given().header(processHeader()).contentType(ContentType.JSON).body(body).when().put(url);
			logReport(LogStatus.PASS, "Executed Put method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Put method in API "+apiName, e);
		}
		return response;
	}
	
	protected Response callRestServiceDelete(String url,String apiName){
		Response response = null;
		try{
			response = RestAssured.given().contentType(ContentType.JSON).when().delete(url);
			logReport(LogStatus.PASS, "Executed Delete method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Delete method in API "+apiName, e);
		}
		return response;
	}
	
	protected Response callRestServiceDelete(String url,String apiName,Header header){
		Response response = null;
		try{
			response = RestAssured.given().header(null).contentType(ContentType.JSON).when().delete(url);
			logReport(LogStatus.PASS, "Executed Delete method for API :"+apiName);
		}catch(Exception e){
			logReport(LogStatus.FAIL, "Exception occurred while performing Delete method in API "+apiName, e);
		}
		return response;
	}
	
	
	public static void setBaseUrl(final String url){
		baseUrl=url;
	}
	
	public String getBaseUrl(){
		return baseUrl;
	}
	
	public static String getToken(){
		return token;
	}
	
	public static void settoken(String strtoken){
		token=strtoken;
	}
	
	public Header processHeader(){
		Header dh = new Header("X-AUTH-TOKEN",RestHelper.getToken());
		return dh;
	}

}
