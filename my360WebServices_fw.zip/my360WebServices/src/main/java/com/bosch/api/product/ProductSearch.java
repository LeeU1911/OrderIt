package com.bosch.api.product;

import com.bosch.Constants;
import com.bosch.util.RestHelper;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;


public class ProductSearch extends RestHelper{
	
	public Response getResponseCodeOfValidProductSearchWithoutAuthentication(String keyWord, String page, String size, String sortField, String sortOrder, String lang, String dataset){
		Header dh = new Header("","");
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productSearch, keyWord, page, size, sortField, sortOrder, lang, dataset),
				dh, null, "Product Search");
		validateResponseCode(200, res.getStatusCode());
		return res;
	}
	
	public void getResponseBodyOfValidProductSearchWithoutAuthentication(String keyWord, String page, String size, String sortField, String sortOrder, String lang, String dataset){
		Header dh = new Header("","");
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productSearch, keyWord, page, size, sortField, sortOrder, lang, dataset),
				dh, null, "Product Search");
		validateResponseContent(res, true);
		System.out.println(res.body().asString());
	}
	
	public Response getResponseOfValidProductSearchWithAuthentication(String keyWord, String page, String size, String sortField, String sortOrder, String lang, String dataset){
		Header dh = new Header("X-AUTH-TOKEN",RestHelper.getToken());
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productSearch, keyWord, page, size, sortField, sortOrder, lang, dataset),
				dh, null, "Product Search");
		validateResponseCode(200, res.getStatusCode());
		validateResponseContent(res, true);
		System.out.println(res.body().asString());
		return res;
	}
	
	public Response getResponseOfInValidProductSearchWithoutAuthentication(String keyWord, String page, String size, String sortField, String sortOrder, String lang, String dataset){
		Header dh = new Header("","");
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productSearch, keyWord, page, size, sortField, sortOrder, lang, dataset),
				dh, null, "Product Search");
		validateResponseCode(200, res.getStatusCode());
		validateResponseContent(res, false);
		System.out.println(res.body().asString());
		return res;
	}

}
