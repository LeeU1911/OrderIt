package com.bosch.api.product;

import com.bosch.Constants;
import com.bosch.util.RestHelper;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;

public class ProductDetails extends RestHelper{
	
	public Response getResponseOfValidProductDetailsWithoutAuthentication(String productId){
		Header dh = new Header("","");
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productDetails, productId),
				dh, null, "Product Details");
		validateResponseCode(200, res.getStatusCode());
		validateResponseContent(res, true);
		System.out.println(res.body().asString());
		return res;
	}
	
	public Response getResponseOfValidProductDetailsWithAuthentication(String productId){
		Header dh = new Header("X-AUTH-TOKEN",RestHelper.getToken());
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productDetails, productId),
				dh, null, "Product Details");
		validateResponseCode(200, res.getStatusCode());
		validateResponseContent(res, true);
		System.out.println(res.body().asString());
		return res;
	}
	
	public Response getResponseOfInValidProductDetailsWithoutAuthentication(String productId){
		Header dh = new Header("","");
		Response res = callRestServiceGet(getBaseUrl()+String.format(Constants.productDetails, productId),
				dh, null, "Product Details");
		validateResponseCode(200, res.getStatusCode());
		validateResponseContent(res, false);
		System.out.println(res.body().asString());
		return res;
	}
	
}
