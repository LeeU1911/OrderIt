package com.bosch.api.inventory;

import com.bosch.Constants;
import com.bosch.util.RestHelper;
import com.jayway.restassured.response.Response;



public class GetInventory extends RestHelper{

	static String productID = "inventoryItems[*].externalProductId";
	static String getNoOfProductWithID = "inventoryItems[?(@.externalProductId=='%s')]";
	
	
	public Response getResponseOfGetInventory(){
		Response res = callRestServiceGet(getBaseUrl()+Constants.getInventory,"Get Inventory");
		System.out.println(res.body().asString());
		validateResponseCode(200, res.getStatusCode());
		return res;
	}
	
	public int getNoOfProductsWithID(Response res,String productID){
		return getListOfElement(res, String.format(getNoOfProductWithID, productID)).size();
	}
	
}
