package com.bosch.api.inventory;

import com.bosch.Constants;
import com.bosch.util.RestHelper;
import com.jayway.restassured.response.Response;

public class AddInventory extends RestHelper{

	public Response addProductToInventory(String productID){
		Response res = callRestServicePost(getBaseUrl()+String.format(Constants.addInventory, productID), "", "Add Inventory");
		validateResponseCode(202, res.getStatusCode());
		return res;
	}
}
