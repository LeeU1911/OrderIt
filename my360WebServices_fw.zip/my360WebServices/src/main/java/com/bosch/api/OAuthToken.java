package com.bosch.api;

import com.bosch.Constants;
import com.bosch.util.PropertyLoader;
import com.bosch.util.RestHelper;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;


public class OAuthToken extends RestHelper{

	public String getaccesstoken() {
		String token = null;
		Header header = new Header("cache-control","no-cache");
		String body = "grant_type=password&username=%s&password=%s&client_id=3026c9e4-2def-4d27-b778-2764fe4c00c9&resource=thingbook-mobile";
		body = String.format(body, PropertyLoader.getTestDataProperty("username"),PropertyLoader.getTestDataProperty("password"));
		Response response = callRestServicePost(Constants.authToken, header, body,ContentType.URLENC, "AuthToken");
		if(response.getStatusCode()!=200){
			logReport(LogStatus.FAIL, "Auth token status code is not 200. Actual: "+response.getStatusCode());
		}else{
			token = response.getBody().jsonPath().getString("access_token");
			logReport(LogStatus.INFO, "AccessToken: "+token);
		}
		return token;
	}
}
