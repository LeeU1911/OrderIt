package com.bosch.api.inventory;

import com.bosch.Constants;
import com.bosch.util.RestHelper;
import com.jayway.restassured.response.Response;


public class DeleteInventory extends RestHelper{

	public Response deleteInventory(){
		Response res = callRestServiceDelete(getBaseUrl()+String.format(Constants.deleteInventory), "Delete Inventory");
		validateResponseCode(200, res.getStatusCode());
		return res;
	}
	
}
