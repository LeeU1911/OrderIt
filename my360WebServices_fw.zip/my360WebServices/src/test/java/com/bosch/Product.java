package com.bosch;

import org.testng.annotations.Test;
import org.testng.annotations.Parameters;

import com.bosch.api.product.ProductSearch;
import com.bosch.api.product.ProductDetails;
import com.bosch.api.product.ProductAttributes;
import com.bosch.util.PropertyLoader;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;
import com.bosch.api.OAuthToken;
import com.bosch.util.RestHelper;

public class Product extends TestNgBase{
	
	@Test
	@Parameters({"keyWord","page","size","sortField","sortOrder","lang","dataset1"})
	public void validProductSearchDatasetAsSubsetWithoutAuthentication(String keyWord,String page,String size,String sortField,String sortOrder,String lang,String dataset1){
		ProductSearch productSearch = new ProductSearch();
		productSearch.getResponseCodeOfValidProductSearchWithoutAuthentication(keyWord, page, size,sortField,sortOrder,lang,dataset1);
		productSearch.getResponseBodyOfValidProductSearchWithoutAuthentication(keyWord, page, size,sortField,sortOrder,lang,dataset1);		
	}
	
	@Test
	@Parameters({"keyWord","page","size","sortField","sortOrder","lang","dataset1"})
	public void validProductSearchDatasetAsSubsetWithAuthentication(String keyWord,String page,String size,String sortField,String sortOrder,String lang,String dataset1){
		OAuthToken token = new OAuthToken();
		String authToken = token.getaccesstoken();
		RestHelper.settoken(authToken);
		ProductSearch productSearch = new ProductSearch();
		productSearch.getResponseOfValidProductSearchWithAuthentication(keyWord, page, size,sortField,sortOrder,lang,dataset1);
	}
	
	@Test
	@Parameters({"keyWord","page","size","sortField","sortOrder","lang","dataset2"})
	public void validProductSearchDatasetAsFullWithoutAuthentication(String keyWord,String page,String size,String sortField,String sortOrder,String lang,String dataset2){
		ProductSearch productSearch = new ProductSearch();
		productSearch.getResponseCodeOfValidProductSearchWithoutAuthentication(keyWord, page, size,sortField,sortOrder,lang,dataset2);
		productSearch.getResponseBodyOfValidProductSearchWithoutAuthentication(keyWord, page, size,sortField,sortOrder,lang,dataset2);
	}
	
	@Test
	@Parameters({"keyWord","page","size","sortField","sortOrder","lang","dataset2"})
	public void validProductSearchDatasetAsFullWithAuthentication(String keyWord,String page,String size,String sortField,String sortOrder,String lang,String dataset2){
		OAuthToken token = new OAuthToken();
		String authToken = token.getaccesstoken();
		RestHelper.settoken(authToken);
		ProductSearch productSearch = new ProductSearch();
		productSearch.getResponseOfValidProductSearchWithAuthentication(keyWord, page, size,sortField,sortOrder,lang,dataset2);	
	}
	
	@Test
	@Parameters({"keyWord2","page","size","sortField","sortOrder","lang","dataset1"})
	public void invalidProductSearchDatasetAsSubsetWithoutAuthentication(String keyWord2,String page,String size,String sortField,String sortOrder,String lang,String dataset1){
		ProductSearch productSearch = new ProductSearch();
		productSearch.getResponseOfInValidProductSearchWithoutAuthentication(keyWord2, page, size,sortField,sortOrder,lang,dataset1);		
	}
	
	@Test
	public void productDetailsValidProductWithoutAuthentication(){
		ProductDetails productDetails = new ProductDetails();
		productDetails.getResponseOfValidProductDetailsWithoutAuthentication(PropertyLoader.getTestDataProperty("product1"));	
	}
	
	@Test
	public void productDetailsValidProductWithAuthentication(){
		OAuthToken token = new OAuthToken();
		String authToken = token.getaccesstoken();
		RestHelper.settoken(authToken);
		ProductDetails productDetails = new ProductDetails();
		productDetails.getResponseOfValidProductDetailsWithAuthentication(PropertyLoader.getTestDataProperty("product1"));	
	}
	
	@Test
	public void productDetailsInValidProductWithoutAuthentication(){
		ProductDetails productDetails = new ProductDetails();
		productDetails.getResponseOfInValidProductDetailsWithoutAuthentication(PropertyLoader.getTestDataProperty("product2"));	
	}
	
	@Test
	public void productAttributesWithAuthentication(){
		OAuthToken token = new OAuthToken();
		String authToken = token.getaccesstoken();
		RestHelper.settoken(authToken);
		ProductAttributes productAttributes = new ProductAttributes();
		productAttributes.getResponseOfValidProductAttributesWithAuthentication();	
	}
	
	@Test
	public void productAttributesWithoutAuthentication(){
		ProductAttributes productAttributes = new ProductAttributes();
		productAttributes.getResponseOfValidProductAttributesWithAuthentication();	
	}
	
}
