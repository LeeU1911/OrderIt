package com.bosch;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.bosch.api.OAuthToken;
import com.bosch.util.CommonFunctions;
import com.bosch.util.CreateExtentReport;
import com.bosch.util.ExtentManager;
import com.bosch.util.ExtentTestManager;
import com.bosch.util.PropertyLoader;
import com.bosch.util.RestHelper;

public class TestNgBase extends CommonFunctions{

	@BeforeSuite
	  public void beforeSuite() throws IOException {
		  PropertyLoader.loadConfigProperty();
		  PropertyLoader.loadTestDataProperty();
		  PropertyLoader.loadURLDataProperty();
		  RestHelper.setBaseUrl(PropertyLoader.getURLProperty(PropertyLoader.getConfigProperty("environment")));
	  }
	
	@BeforeMethod
	public void beforeMethod(Method method){
		System.setProperty("https.proxyHost", "rb-proxy-apac.bosch.com");
		System.setProperty("https.proxyPort", "8080");
		ExtentTestManager.startTest(method.getName());
		/*OAuthToken token=new OAuthToken();
		String authToken = token.getaccesstoken();
		RestHelper.settoken(authToken);*/
	}
	
	@AfterMethod
	public void afterMethod(){
		ExtentTestManager.endTest();
	}
	
	@AfterSuite
	public void afterSuite(){
		ExtentManager.endReport();
	}
}
